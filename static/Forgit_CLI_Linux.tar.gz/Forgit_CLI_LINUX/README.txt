______                  _  _
|  ___|                (_)| |
| |_  ___   _ __  __ _  _ | |_
|  _|/ _ \ |  __|/ _  || || __|
| | | (_) || |  | (_| || || |_
\_|  \___/ |_|   \__, ||_| \__|
                  __/ |
                 |___/


Thank you for downloading Forgit CLI!

>_ About Me
Created by: Kevin Tucker
Github: https://github.com/kwtucker
Forgit: http://forgit.whalebyte.com/

>_ Description
Forgit CLI is the shell application that will run git add, commit, pull, push for you after you have started the CLI.
It is a tool to communicate to git, github, and forgit.whalebyte.com.
All made with Go programming language.

>_ Getting Started
1. Run forgit init ( It will ask you for your UUID that is on your dashboard on forgit.whalebyte.com ).
2. Be sure to have repos in the Forgit directory once it is created from the forgit init command.
3. If you haven't already set settings on your dashboard on forgit.whalebyte.com.
4. Now Run the forgit start.
	- Examples:
		For one session only: forgit start -c 5 -p 15
		Select setting group: forgit start g General
5. To stop just close terminal window or control-c.
6. For help: forgit help